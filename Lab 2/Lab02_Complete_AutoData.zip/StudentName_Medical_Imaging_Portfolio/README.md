# Medical Imaging Portfolio

Run each notebook from inside its own task folder.

The notebooks automatically find and download only the specific sample data they use. No full multi-gigabyte dataset is downloaded and no manual image/video placement is required.

- `Task_1_Chest_Xray/xray_enhancement.ipynb`
- `Task_2_Cardiac_Fusion/modal_fusion.ipynb`
- `Task_3_Echo_Analysis/realtime_echo.ipynb`

Install dependencies with:

```bash
pip install -r requirements.txt
```
