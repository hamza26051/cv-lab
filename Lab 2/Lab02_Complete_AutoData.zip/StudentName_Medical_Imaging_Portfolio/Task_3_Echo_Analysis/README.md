# Task 3 Echo Analysis

Run `realtime_echo.ipynb`.

The notebook automatically obtains a short echocardiogram video, saves it as `data/echo.mp4`, processes every frame in a `while` loop using histogram equalization, JET mapping, color balance, logarithmic transformation and power-law transformation, then writes the raw and enhanced streams side-by-side to `output/`.

Primary dataset: `manojkumarcs28/echonet-dynamic-by-stanford-university` on Kaggle.
Fallback sample: the public EchoNet-Dynamic demo media from the official `echonet/dynamic` repository.
