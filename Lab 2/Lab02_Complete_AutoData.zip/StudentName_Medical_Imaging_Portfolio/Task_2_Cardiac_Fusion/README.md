# Task 2 Cardiac Fusion

Run `modal_fusion.ipynb`.

The notebook automatically inspects the Heart CT & MRI Dataset, selects a compact CT/MRI pair, downloads only those files, converts the medical image format to grayscale PNG when required, equalizes each modality, applies color maps, performs weighted fusion with CT weight 0.65 and MRI weight 0.35, then applies logarithmic and power-law transformations. Results are saved in `output/`.

Dataset: `ziya07/heart-ct-and-mri-dataset` on Kaggle.
