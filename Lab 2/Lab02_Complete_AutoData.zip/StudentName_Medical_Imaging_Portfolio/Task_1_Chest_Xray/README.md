# Task 1 Chest X-Ray

Run `xray_enhancement.ipynb`.

The notebook automatically obtains one chest X-ray sample, saves it in `data/`, then performs histogram equalization, JET color mapping, color balance, strict high-intensity thresholding, logarithmic transformation and gamma correction. Results are saved in `output/`.

Primary dataset: `sachinkumar413/covid-pneumonia-normal-chest-xray-images` on Kaggle.
